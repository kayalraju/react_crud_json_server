import './App.css';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Home from './components/Home'
import AllUser from './components/AllUser'
import Navbar from './components/Navbar'
import AddUser from './components/AddUser'

function App() {
  return (
    <div>
      <Router>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/alluser' element={<AllUser/>}/>
          <Route path='/adduser' element={<AddUser/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
