import React from 'react'

export default function Edit() {
  return (
    <div>
        <h1>edit</h1>
    </div>
  )
}
